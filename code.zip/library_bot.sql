DROP TABLE IF EXISTS users CASCADE;

CREATE TABLE users (
    id SERIAL PRIMARY KEY,  -- Уникальный идентификатор
    telegram_id BIGINT UNIQUE NOT NULL,  -- ID пользователя в Telegram
    email VARCHAR(255) UNIQUE NOT NULL CHECK (email LIKE '%@%'),  -- Email пользователя с проверкой
    password_hash TEXT NOT NULL CHECK (LENGTH(password_hash) >= 8),  -- Хэшированный пароль с проверкой длины
    name VARCHAR(100) NOT NULL,  -- Имя пользователя
    surname VARCHAR(100) NOT NULL,  -- Фамилия пользователя
    role VARCHAR(50) NOT NULL CHECK (role IN ('ученик', 'учитель', 'библиотекарь')),  -- Роль пользователя
    class_or_subject VARCHAR(100),  -- Класс или предмет
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP  -- Дата регистрации
);

-- Вставка данных в таблицу пользователей
INSERT INTO users (telegram_id, email, password_hash, name, surname, role, class_or_subject)
VALUES
(1234567890, 'ivanov@example.com', 'hashed_password_1', 'Иван', 'Иванов', 'ученик', '10-А'),
(2345678901, 'petrov@example.com', 'hashed_password_2', 'Петр', 'Петров', 'ученик', '10-Б'),
(3456789012, 'sidorov@example.com', 'hashed_password_3', 'Сидор', 'Сидоров', 'учитель', 'Математика'),
(4567890123, 'volkov@example.com', 'hashed_password_4', 'Владимир', 'Волков', 'учитель', 'Физика'),
(5678901234, 'orlov@example.com', 'hashed_password_5', 'Олег', 'Орлов', 'библиотекарь', NULL),
(6789012345, 'guseva@example.com', 'hashed_password_6', 'Алина', 'Гусева', 'ученик', '9-А'),
(7890123456, 'tikhomirova@example.com', 'hashed_password_7', 'Анастасия', 'Тихомирова', 'ученик', '9-Б'),
(8901234567, 'kuznetsov@example.com', 'hashed_password_8', 'Сергей', 'Кузнецов', 'учитель', 'История'),
(9012345678, 'popova@example.com', 'hashed_password_9', 'Елена', 'Попова', 'библиотекарь', NULL),
(1123456789, 'nikolaev@example.com', 'hashed_password_10', 'Никита', 'Николаев', 'ученик', '8-А');

DROP TABLE IF EXISTS books CASCADE;

CREATE TABLE books (
    id SERIAL PRIMARY KEY,  -- Уникальный идентификатор книги
    title VARCHAR(200) NOT NULL,  -- Название книги
    author VARCHAR(150) NOT NULL,  -- Автор книги
    genre VARCHAR(100) NOT NULL,  -- Жанр книги
    description TEXT,  -- Описание книги
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP  -- Дата добавления книги
);

-- Вставка данных в таблицу книг
INSERT INTO books (title, author, genre, description)
VALUES
('Война и мир', 'Лев Толстой', 'Классика', 'Эпическое произведение о Наполеоновских войнах и русском обществе.'),
('Преступление и наказание', 'Фёдор Достоевский', 'Классика', 'История бедного студента Раскольникова, который совершает убийство и борется с чувством вины.'),
('1984', 'Джордж Оруэлл', 'Научная фантастика', 'Антиутопия о тоталитарном обществе будущего.'),
('Гарри Поттер и философский камень', 'Дж.К. Роулинг', 'Фантастика', 'Приключения молодого волшебника Гарри Поттера.'),
('Мастер и Маргарита', 'Михаил Булгаков', 'Фантастика', 'Мистическая история о встрече дьявола с советской Москвой.'),
('Собачье сердце', 'Михаил Булгаков', 'Сатира', 'Сатирическая история о превращении собаки в человека.'),
('Дети Арбата', 'Анатолий Рыбаков', 'История', 'История жизни молодежи в советском обществе в 1930-е годы.'),
('Фаустиада', 'Александр Пушкин', 'Поэзия', 'Поэма о борьбе между добром и злом в человеческой душе.'),
('Обломов', 'Иван Гончаров', 'Классика', 'История ленивого и бездеятельного дворянина Ильи Обломова.'),
('Шерлок Холмс', 'Артур Конан Дойл', 'Детектив', 'Приключения знаменитого детектива Шерлока Холмса.');

SELECT * FROM books

DROP TABLE IF EXISTS book_inventory CASCADE;

CREATE TABLE book_inventory (
    id SERIAL PRIMARY KEY,  -- Уникальный идентификатор записи
    book_id INT NOT NULL REFERENCES books(id) ON DELETE CASCADE,  -- ID книги
    total_copies INT NOT NULL CHECK (total_copies >= 0),  -- Общее количество экземпляров
    available_copies INT NOT NULL CHECK (available_copies >= 0)  -- Количество доступных экземпляров
);

-- Вставка данных в таблицу складов книг
INSERT INTO book_inventory (book_id, total_copies, available_copies)
VALUES
(1, 10, 10),
(2, 8, 8),
(3, 12, 12),
(4, 15, 15),
(5, 7, 7),
(6, 9, 9),
(7, 10, 10),
(8, 5, 5),
(9, 10, 10),
(10, 14, 14);

DROP TABLE IF EXISTS recommendations CASCADE;

CREATE TABLE recommendations (
    id SERIAL PRIMARY KEY,  -- Уникальный идентификатор
    user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,  -- ID пользователя
    genre VARCHAR(100) NOT NULL,  -- Жанр книги
    recommended_books TEXT,  -- Список рекомендованных книг
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP  -- Дата создания рекомендации
);

-- Вставка данных в таблицу рекомендаций
INSERT INTO recommendations (user_id, genre, recommended_books)
VALUES
(1, 'Фантастика', '{"books": ["Гарри Поттер и философский камень", "1984"]}'),
(2, 'Детектив', '{"books": ["Шерлок Холмс", "Преступление и наказание"]}'),
(3, 'Классика', '{"books": ["Обломов", "Мастер и Маргарита"]}'),
(4, 'Фантастика', '{"books": ["Гарри Поттер и философский камень"]}'),
(5, 'Классика', '{"books": ["Война и мир", "Дети Арбата"]}'),
(6, 'Сатира', '{"books": ["Собачье сердце", "Шерлок Холмс"]}'),
(7, 'Поэзия', '{"books": ["Фаустиада"]}'),
(8, 'Фантастика', '{"books": ["Мастер и Маргарита", "Гарри Поттер и философский камень"]}'),
(9, 'Классика', '{"books": ["Обломов"]}'),
(10, 'Детектив', '{"books": ["Шерлок Холмс"]}');

DROP TABLE IF EXISTS admins CASCADE;

CREATE TABLE admins (
    id SERIAL PRIMARY KEY,            -- Уникальный ID для администратора
    telegram_id VARCHAR(50) UNIQUE NOT NULL, -- Telegram ID 
    name VARCHAR(100) NOT NULL,       -- Имя администратора
    surname VARCHAR(100) NOT NULL,    -- Фамилия администратора
    role VARCHAR(20) NOT NULL,        -- Роль (должен быть "администратор")
    permissions TEXT                  -- Разрешения администратора 
);

-- Добавление администраторов
INSERT INTO admins (telegram_id, name, surname, role)
VALUES
('123456789', 'Светлана', 'Иванова', 'администратор'),
('987654321', 'Мария', 'Петрова', 'администратор'),
('234567891', 'Алексей', 'Иванов', 'администратор');

SELECT * FROM admins WHERE telegram_id = '123456789'; -- Используйте реальный telegram_id


-- Создаем функцию для обновления доступных копий
CREATE OR REPLACE FUNCTION update_available_copies()
RETURNS TRIGGER AS $$
BEGIN
    IF (TG_OP = 'INSERT' OR TG_OP = 'UPDATE') THEN
        -- Проверяем, чтобы доступные копии не превышали общее количество копий
        IF NEW.available_copies > NEW.total_copies THEN
            RAISE EXCEPTION 'Available copies cannot exceed total copies.';
        END IF;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Создаем триггер для таблицы book_inventory
CREATE TRIGGER trg_update_copies
BEFORE INSERT OR UPDATE ON book_inventory
FOR EACH ROW
EXECUTE FUNCTION update_available_copies();

-- Создаем представление для полной информации о книгах
CREATE OR REPLACE VIEW full_books_view AS
SELECT 
    b.id AS book_id,
    b.title AS book_title,
    b.author AS book_author,
    bi.total_copies,
    bi.available_copies,
    b.description,
    b.created_at
FROM books b
JOIN book_inventory bi ON b.id = bi.book_id;

-- Просмотр данных из представления
SELECT * FROM full_books_view;


-- INNER JOIN: Получить список книг с информацией о жанре
SELECT 
    b.id AS book_id,
    b.title AS book_title,
    b.author AS book_author,
    b.genre AS genre,
    bi.total_copies,
    bi.available_copies
FROM books b
INNER JOIN book_inventory bi ON b.id = bi.book_id;

-- Тестирование INNER JOIN
SELECT 
    b.title AS "Название книги",
    b.author AS "Автор",
    bi.total_copies AS "Всего экземпляров",
    bi.available_copies AS "Доступно"
FROM books b
INNER JOIN book_inventory bi ON b.id = bi.book_id;


-- LEFT JOIN: Получить всех пользователей и их рекомендации (если есть)
SELECT 
    u.id AS user_id,
    u.name AS user_name,
    u.surname AS user_surname,
    r.recommended_books
FROM users u
LEFT JOIN recommendations r ON u.id = r.user_id;

-- Тестирование LEFT JOIN
SELECT 
    u.name AS "Имя пользователя",
    u.surname AS "Фамилия пользователя",
    COALESCE(r.recommended_books, 'Нет рекомендаций') AS "Рекомендации"
FROM users u
LEFT JOIN recommendations r ON u.id = r.user_id;


--для поиска по названию книги
CREATE INDEX idx_books_title ON books (title);

--для поиска по жанру книги
CREATE INDEX idx_books_genre ON books (genre);

--для ускорения поиска пользователей по email
CREATE INDEX idx_users_email ON users (email);

-- ограничиваем длину пароля
ALTER TABLE users
ADD CONSTRAINT chk_password_length CHECK (LENGTH(password_hash) >= 8);